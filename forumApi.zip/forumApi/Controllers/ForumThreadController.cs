﻿using forumApi.Data;
using forumApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace forumApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class ForumThreadController : Controller
    {
        public readonly ForumAPIDbContext dbContext;

        public ForumThreadController(ForumAPIDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllPosts()
        {
            return Ok(await dbContext.ForumThreads.ToListAsync());
        }

        [HttpGet]
        [Route("{id:guid}")]
        public async Task<IActionResult> GetPost(Guid id)
        {
            var post = await dbContext.ForumThreads.FindAsync(id);

            if (post == null)
            {
                return NotFound();
            }

            return Ok(post);
        }

        [HttpPost]
        public async Task<IActionResult> AddPost(AddForumPost addForumPost)
        {
            var post = new ForumThread()
            {
                Id = Guid.NewGuid(),
                ThreadName = addForumPost.ThreadName,
                Title = addForumPost.Title,
                Category = addForumPost.Category,
                TextContent = addForumPost.TextContent,
                ImagePost = addForumPost.ImagePost,
            };
            await dbContext.ForumThreads.AddAsync(post);
            await dbContext.SaveChangesAsync();

            return Ok(post);

        }

        [HttpPut]
        [Route("{id:guid}")]

        public async Task<IActionResult> UpdatePost([FromRoute] Guid id, UpdateForumPost updateForumPost)
        
        {
            var post = await dbContext.ForumThreads.FindAsync(id);

            if (post != null)
            {
                post.TextContent = updateForumPost.TextContent;
                post.Title = updateForumPost.Title;
                post.Category = updateForumPost.Category;
                post.ImagePost = updateForumPost.ImagePost;

                await dbContext.SaveChangesAsync();
                return Ok(post);
            }
            return NotFound();

        }

        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeletePost([FromRoute] Guid id)

        {
            var post = await dbContext.ForumThreads.FindAsync(id);
            if (post != null)
            {
                dbContext.Remove(post);
                 await dbContext.SaveChangesAsync();
                return Ok("Post was deleted");
            }
            return NotFound();
        }



        }
}
