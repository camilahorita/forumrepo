﻿namespace forumApi.Models
{
    public class ForumThread
    {
        public Guid Id { get; set; }

        public string ThreadName { get; set; }

        public string Title { get; set; }

        public string Category { get; set; }

        public string TextContent { get; set; }

        public string ImagePost { get; set;}


    }
}
