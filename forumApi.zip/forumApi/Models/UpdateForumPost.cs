﻿namespace forumApi.Models
{
    public class UpdateForumPost
    {

        public string Title { get; set; }

        public string Category { get; set; }

        public string TextContent { get; set; }

        public string ImagePost { get; set; }
    }
}
