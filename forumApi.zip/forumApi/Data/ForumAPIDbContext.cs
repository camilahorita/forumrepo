﻿using forumApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography.X509Certificates;

namespace forumApi.Data
{
    public class ForumAPIDbContext : DbContext
    {
        public ForumAPIDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<ForumThread> ForumThreads { get; set; }
    }
}
